import React from 'react';
import { Car, RotateCcw, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-react';

interface PredictionResultProps {
  prediction: number | null;
  onReset: () => void;
}

const PredictionResult: React.FC<PredictionResultProps> = ({ prediction, onReset }) => {
  if (prediction === null) return null;

  const getTrafficLevel = (volume: number) => {
    if (volume < 1000) return { level: 'Low', color: 'green', icon: CheckCircle };
    if (volume < 3000) return { level: 'Moderate', color: 'yellow', icon: TrendingUp };
    if (volume < 5000) return { level: 'High', color: 'orange', icon: AlertTriangle };
    return { level: 'Very High', color: 'red', icon: AlertTriangle };
  };

  const trafficInfo = getTrafficLevel(prediction);
  const IconComponent = trafficInfo.icon;

  const getColorClasses = (color: string) => {
    switch (color) {
      case 'green':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'yellow':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'orange':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'red':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white shadow-xl rounded-lg p-8 text-center">
        {/* Success Icon */}
        <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-green-100 mb-6">
          <Car className="h-8 w-8 text-green-600" />
        </div>

        {/* Title */}
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Prediction Complete!
        </h2>

        {/* Main Result */}
        <div className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white p-6 rounded-lg mb-6">
          <h3 className="text-lg font-medium mb-2">Estimated Traffic Volume</h3>
          <p className="text-4xl font-bold">
            {Math.round(prediction).toLocaleString()} vehicles
          </p>
        </div>

        {/* Traffic Level Indicator */}
        <div className={`inline-flex items-center px-4 py-2 rounded-full border-2 mb-6 ${getColorClasses(trafficInfo.color)}`}>
          <IconComponent className="h-5 w-5 mr-2" />
          <span className="font-semibold">{trafficInfo.level} Traffic</span>
        </div>

        {/* Additional Info */}
        <div className="bg-gray-50 p-4 rounded-lg mb-6">
          <h4 className="font-semibold text-gray-900 mb-2">About This Prediction</h4>
          <p className="text-gray-600 text-sm">
            This prediction was generated using a Random Forest machine learning model 
            trained on historical traffic data. The model considers weather conditions, 
            holidays, and other factors to estimate traffic volume with 97% accuracy.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <button
            onClick={onReset}
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-200"
          >
            <RotateCcw className="h-5 w-5 mr-2" />
            Make Another Prediction
          </button>
        </div>

        {/* Traffic Level Guide */}
        <div className="mt-8 pt-6 border-t border-gray-200">
          <h4 className="text-sm font-medium text-gray-900 mb-3">Traffic Level Guide</h4>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
            <div className="bg-green-100 text-green-800 px-2 py-1 rounded">
              Low: &lt;1,000
            </div>
            <div className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded">
              Moderate: 1,000-3,000
            </div>
            <div className="bg-orange-100 text-orange-800 px-2 py-1 rounded">
              High: 3,000-5,000
            </div>
            <div className="bg-red-100 text-red-800 px-2 py-1 rounded">
              Very High: &gt;5,000
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PredictionResult;