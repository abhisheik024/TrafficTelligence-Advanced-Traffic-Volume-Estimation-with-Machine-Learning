import React from 'react';
import { Car, Target, Users, BarChart3, CheckCircle, Globe, Zap, Shield } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="text-center mb-12">
        <div className="flex justify-center mb-4">
          <Car className="h-16 w-16 text-indigo-600" />
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">TrafficTelligence</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Advanced Traffic Volume Estimation with Machine Learning
        </p>
      </div>

      {/* About Section */}
      <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">About the Project</h2>
        <p className="text-gray-600 leading-relaxed">
          TrafficTelligence is an advanced system that uses machine learning algorithms to estimate 
          and predict traffic volume with precision. By analyzing historical traffic data, weather 
          patterns, events, and other relevant factors, TrafficTelligence provides accurate forecasts 
          and insights to enhance traffic management, urban planning, and commuter experiences.
        </p>
      </div>

      {/* Key Features */}
      <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Key Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="flex items-start">
            <Globe className="h-6 w-6 text-blue-500 mt-1 mr-3 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Weather Integration</h3>
              <p className="text-gray-600 text-sm">
                Incorporates real-time weather data including temperature, rainfall, snow, 
                and cloud coverage to improve prediction accuracy.
              </p>
            </div>
          </div>
          
          <div className="flex items-start">
            <CheckCircle className="h-6 w-6 text-green-500 mt-1 mr-3 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Holiday Detection</h3>
              <p className="text-gray-600 text-sm">
                Considers holidays and special events that significantly impact traffic 
                patterns and volume.
              </p>
            </div>
          </div>
          
          <div className="flex items-start">
            <BarChart3 className="h-6 w-6 text-purple-500 mt-1 mr-3 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Machine Learning</h3>
              <p className="text-gray-600 text-sm">
                Uses Random Forest algorithm with 97% accuracy for reliable traffic 
                volume predictions.
              </p>
            </div>
          </div>
          
          <div className="flex items-start">
            <Zap className="h-6 w-6 text-yellow-500 mt-1 mr-3 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Real-time Interface</h3>
              <p className="text-gray-600 text-sm">
                User-friendly web application for easy input and instant traffic 
                volume predictions.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Use Cases */}
      <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Use Cases</h2>
        <div className="space-y-6">
          <div className="flex items-start">
            <Target className="h-6 w-6 text-indigo-500 mt-1 mr-3 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Dynamic Traffic Management</h3>
              <p className="text-gray-600 text-sm">
                Transportation authorities can implement adaptive traffic control systems, 
                adjust signal timings, and optimize lane configurations to reduce congestion 
                and improve traffic flow.
              </p>
            </div>
          </div>
          
          <div className="flex items-start">
            <Users className="h-6 w-6 text-green-500 mt-1 mr-3 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Urban Development Planning</h3>
              <p className="text-gray-600 text-sm">
                City planners and urban developers can leverage TrafficTelligence predictions 
                to plan new infrastructure projects effectively, designing road networks and 
                commercial zones optimized for traffic efficiency.
              </p>
            </div>
          </div>
          
          <div className="flex items-start">
            <Car className="h-6 w-6 text-blue-500 mt-1 mr-3 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Commuter Guidance</h3>
              <p className="text-gray-600 text-sm">
                Individual commuters and navigation apps can benefit from accurate traffic 
                volume estimations to plan routes intelligently and select optimal travel 
                times based on predicted conditions.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Technology Stack */}
      <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Technology Stack</h2>
        <p className="text-gray-600 mb-4">
          This project is built using cutting-edge technologies and frameworks:
        </p>
        <div className="flex flex-wrap gap-2">
          {[
            'React', 'TypeScript', 'Tailwind CSS', 'Machine Learning', 
            'Random Forest', 'Data Science', 'Weather APIs', 'Responsive Design'
          ].map((tech) => (
            <span 
              key={tech}
              className="bg-indigo-100 text-indigo-800 px-3 py-1 rounded-full text-sm font-medium"
            >
              {tech}
            </span>
          ))}
        </div>
      </div>

      {/* Model Performance */}
      <div className="bg-white rounded-lg shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Model Performance</h2>
        <p className="text-gray-600 mb-4">
          Our Random Forest model achieved impressive results:
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex items-center mb-2">
              <Shield className="h-5 w-5 text-green-500 mr-2" />
              <span className="font-semibold text-gray-900">Accuracy</span>
            </div>
            <p className="text-2xl font-bold text-green-600">97%</p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex items-center mb-2">
              <BarChart3 className="h-5 w-5 text-blue-500 mr-2" />
              <span className="font-semibold text-gray-900">Algorithm</span>
            </div>
            <p className="text-lg font-semibold text-blue-600">Random Forest</p>
          </div>
        </div>
        <div className="mt-4 text-sm text-gray-600">
          <p><strong>Features:</strong> Holiday status, Temperature, Rain, Snow, Cloud Coverage, Weather Conditions</p>
          <p><strong>Data Processing:</strong> Feature scaling using StandardScaler equivalent</p>
        </div>
      </div>
    </div>
  );
};

export default About;