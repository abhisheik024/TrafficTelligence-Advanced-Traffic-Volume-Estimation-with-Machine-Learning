import React, { useState } from 'react';
import { Thermometer, CloudRain, CloudSnow, Cloud, Calendar } from 'lucide-react';
import { predictTrafficVolume } from '../utils/trafficModel';

interface PredictionFormProps {
  onPredict: (result: number) => void;
}

const PredictionForm: React.FC<PredictionFormProps> = ({ onPredict }) => {
  const [formData, setFormData] = useState({
    holiday: 0,
    temp: 298.15, // Default temperature in Kelvin (25°C)
    rain_1h: 0.0,
    snow_1h: 0.0,
    clouds_all: 25,
    weather_main: 'Clear'
  });

  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'holiday' ? parseInt(value) : 
               ['temp', 'rain_1h', 'snow_1h', 'clouds_all'].includes(name) ? parseFloat(value) : value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      const prediction = predictTrafficVolume(formData);
      onPredict(prediction);
      setIsLoading(false);
    }, 1000);
  };

  const tempCelsius = Math.round(formData.temp - 273.15);

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white shadow-xl rounded-lg p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
          Enter Traffic Conditions
        </h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Holiday */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <Calendar className="h-4 w-4 mr-2 text-indigo-500" />
              Holiday Status
            </label>
            <select
              name="holiday"
              value={formData.holiday}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              required
            >
              <option value={0}>No (Regular Day)</option>
              <option value={1}>Yes (Holiday)</option>
            </select>
          </div>

          {/* Temperature */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <Thermometer className="h-4 w-4 mr-2 text-red-500" />
              Temperature ({tempCelsius}°C / {formData.temp}K)
            </label>
            <input
              type="number"
              name="temp"
              value={formData.temp}
              onChange={handleInputChange}
              step="0.01"
              min="200"
              max="350"
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Temperature in Kelvin (e.g., 298.15)"
              required
            />
            <p className="text-xs text-gray-500 mt-1">Enter temperature in Kelvin (273.15K = 0°C)</p>
          </div>

          {/* Rain and Snow Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                <CloudRain className="h-4 w-4 mr-2 text-blue-500" />
                Rain (1 hour) mm
              </label>
              <input
                type="number"
                name="rain_1h"
                value={formData.rain_1h}
                onChange={handleInputChange}
                step="0.01"
                min="0"
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="e.g., 0.25"
                required
              />
            </div>

            <div>
              <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
                <CloudSnow className="h-4 w-4 mr-2 text-gray-400" />
                Snow (1 hour) mm
              </label>
              <input
                type="number"
                name="snow_1h"
                value={formData.snow_1h}
                onChange={handleInputChange}
                step="0.01"
                min="0"
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="e.g., 0.0"
                required
              />
            </div>
          </div>

          {/* Cloud Coverage */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <Cloud className="h-4 w-4 mr-2 text-gray-500" />
              Cloud Coverage (%)
            </label>
            <input
              type="number"
              name="clouds_all"
              value={formData.clouds_all}
              onChange={handleInputChange}
              min="0"
              max="100"
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="e.g., 75"
              required
            />
          </div>

          {/* Weather Condition */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <Cloud className="h-4 w-4 mr-2 text-indigo-500" />
              Weather Condition
            </label>
            <select
              name="weather_main"
              value={formData.weather_main}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              required
            >
              <option value="Clear">Clear</option>
              <option value="Clouds">Clouds</option>
              <option value="Rain">Rain</option>
              <option value="Snow">Snow</option>
              <option value="Mist">Mist</option>
              <option value="Fog">Fog</option>
              <option value="Thunderstorm">Thunderstorm</option>
              <option value="Drizzle">Drizzle</option>
            </select>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-indigo-600 text-white py-3 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
          >
            {isLoading ? (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                Predicting...
              </div>
            ) : (
              'Predict Traffic Volume'
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default PredictionForm;