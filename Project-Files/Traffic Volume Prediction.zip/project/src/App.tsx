import React, { useState } from 'react';
import { Car, Cloud, Thermometer, CloudRain, CloudSnow, Calendar, BarChart3 } from 'lucide-react';
import PredictionForm from './components/PredictionForm';
import PredictionResult from './components/PredictionResult';
import About from './components/About';
import DataExploration from './components/DataExploration';

function App() {
  const [currentView, setCurrentView] = useState<'home' | 'about' | 'data'>('home');
  const [prediction, setPrediction] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);

  const handlePrediction = (result: number) => {
    setPrediction(result);
    setShowResult(true);
  };

  const resetView = () => {
    setShowResult(false);
    setPrediction(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Navigation */}
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Car className="h-8 w-8 text-indigo-600 mr-3" />
              <span className="text-xl font-bold text-gray-900">TrafficTelligence</span>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => { setCurrentView('home'); resetView(); }}
                className={`px-3 py-2 rounded-md text-sm font-medium ${
                  currentView === 'home' 
                    ? 'bg-indigo-100 text-indigo-700' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Predict
              </button>
              <button
                onClick={() => setCurrentView('data')}
                className={`px-3 py-2 rounded-md text-sm font-medium ${
                  currentView === 'data' 
                    ? 'bg-indigo-100 text-indigo-700' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                <BarChart3 className="h-4 w-4 inline mr-1" />
                Data Analysis
              </button>
              <button
                onClick={() => setCurrentView('about')}
                className={`px-3 py-2 rounded-md text-sm font-medium ${
                  currentView === 'about' 
                    ? 'bg-indigo-100 text-indigo-700' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                About
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {currentView === 'home' && (
          <div className="px-4 py-6 sm:px-0">
            {!showResult ? (
              <>
                {/* Header */}
                <div className="text-center mb-8">
                  <h1 className="text-4xl font-bold text-gray-900 mb-4">
                    Traffic Volume Prediction
                  </h1>
                  <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                    Advanced Traffic Volume Estimation with Machine Learning. 
                    Predict traffic patterns using weather conditions, holidays, and other factors.
                  </p>
                </div>

                {/* Features */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                  <div className="bg-white p-6 rounded-lg shadow-md text-center">
                    <Cloud className="h-12 w-12 text-blue-500 mx-auto mb-3" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Weather Integration</h3>
                    <p className="text-gray-600">Real-time weather data analysis</p>
                  </div>
                  <div className="bg-white p-6 rounded-lg shadow-md text-center">
                    <Calendar className="h-12 w-12 text-green-500 mx-auto mb-3" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Holiday Detection</h3>
                    <p className="text-gray-600">Special events impact analysis</p>
                  </div>
                  <div className="bg-white p-6 rounded-lg shadow-md text-center">
                    <BarChart3 className="h-12 w-12 text-purple-500 mx-auto mb-3" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">97% Accuracy</h3>
                    <p className="text-gray-600">Random Forest algorithm</p>
                  </div>
                  <div className="bg-white p-6 rounded-lg shadow-md text-center">
                    <Car className="h-12 w-12 text-indigo-500 mx-auto mb-3" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Real-time Prediction</h3>
                    <p className="text-gray-600">Instant traffic volume estimates</p>
                  </div>
                </div>

                <PredictionForm onPredict={handlePrediction} />
              </>
            ) : (
              <PredictionResult 
                prediction={prediction} 
                onReset={resetView}
              />
            )}
          </div>
        )}

        {currentView === 'about' && <About />}
        {currentView === 'data' && <DataExploration />}
      </main>
    </div>
  );
}

export default App;